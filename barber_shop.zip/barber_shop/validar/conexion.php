<?php
$host="localhost";
$user="root";
$password="";
$db="barber_shop";
$con = new mysqli($host,$user,$password,$db);

?>