<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container">
        <a class="navbar-brand" href="barber_shop.php">Reggae Barber</a>
       
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active"><a href="barber_shop.php" class="nav-link">Inicio</a></li>        
            <li class="nav-item"><a href="admin/index.php" class="nav-link">Admin</a></li>
          </ul>
        </div>
      </div>
    </nav>