<!--footer-->
    <div class="footer">
       <p>&copy; 2020 ConfiguroWeb | Panel Administrativo.</p>
    </div>
        <!--//footer-->